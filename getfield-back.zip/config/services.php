<?php
return [
   
    'google' => [
        'client_id' => '938990935440-46pn99llh4fg285h7ghsl0jve2o68ek8.apps.googleusercontent.com',
        'client_secret' => '0mNo3PDOX76QOYy4iLMjsjK9',
        'redirect' => env('APP_URL').'/auth/adwords/callback'
    ],
];
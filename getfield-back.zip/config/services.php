<?php
return [
   
    'google' => [
        'client_id' => '134970730214-r9hhrqa43te06vrr4kv4tqobgkrm9tf7.apps.googleusercontent.com',
        'client_secret' => 'Eeu6qehpkA_OoE9ItXlWpuHI',
        'redirect' => env('APP_URL').'/auth/adwords/callback'
    ],
];